/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package opbitequals;

/**
 *
 * @author D
 */
public class OpBitEquals {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a = 1;
        int b = 2;
        int c = 3;
         a |= 4;
         b >>=1;
         c <<=1;
         a ^=c;
         System.out.println (" a = " + a);
         System.out.println(" b = " + b);
         System.out.println(" c = " + c);

    }

}
