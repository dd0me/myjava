/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jumpstatements;

/**
 *
 * @author D
 */
public class BreakLabelExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Example using break label
        boolean t = true;

        yakwanza: {
            yapili: {
                yatatu: {
                    System.out.println("Before the break");
                    if (t) break yapili;//resumes at the end of the second label
                    System.out.println("This wont execute");
                }
               System.out.println("This wont execute");
            }
        System.out.println("Resumes here!");
        }

    }

}
