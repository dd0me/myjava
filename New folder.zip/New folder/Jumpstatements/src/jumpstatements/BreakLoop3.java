/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jumpstatements;

/**
 *
 * @author D
 */
public class BreakLoop3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Illustration of a break statement in a nested loop
  for(int i=0;i<1000000;i++){
      System.out.println(" PASS " + i + " : ");
      for(int j=0;j<1000000;j++){
          if (j==290000)break; //this breaks the loop statement
          System.out.print(j + " ");
      }
       System.out.println();   
      }
  System.out.println("Loop completes");
      }
        }
    



