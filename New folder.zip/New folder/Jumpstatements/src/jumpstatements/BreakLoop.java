/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jumpstatements;

/**
 *
 * @author D
 */
public class BreakLoop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Demonstrating the break statement in a loop
        int i;
        for(i=0;i<100;i++){
            if(i==58)break;
        System.out.println("This is i " + i);
            }
    System.out.println("Loop complete ");
    }
}
