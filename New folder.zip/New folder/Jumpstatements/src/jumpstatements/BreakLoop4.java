/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jumpstatements;

/**
 *
 * @author D
 */
public class BreakLoop4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Using the jump statement labelled break, to exit from nested loops
        outer:for(int i=0;i<3;i++){
            System.out.print("Pass " + ":");
            for(int j=0;j<100;j++){
                if (j==10) break outer;//this exits both loops
                System.out.print(j + " ");
            }
            System.out.println("This will not print");
        }
        System.out.println(" This will print ");
    }

}
