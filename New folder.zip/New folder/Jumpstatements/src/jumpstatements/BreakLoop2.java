/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jumpstatements;

/**
 *
 * @author D
 */
public class BreakLoop2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Illustrating the break loop usng the while statement
        int i=0;
        while(i<100) {
            if(i==10)break;//terminate statement if i is equal to 10
            System.out.println("This is i " + i);
            i++;
        }
        System.out.println("Loop is complete");
        }

    }

