/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class MultByTwo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Left shifting as quick way to multiply by 2
        int i;
        int num = 0xFFFFFFE;
        for(i=0;i<4;i++){
            num=num<<1;
            System.out.println(num);
        }
    }

}
