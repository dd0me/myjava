/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class ByteShift {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     //Left shifting a byte value
        byte a=64,b;
        int i;
        i=a<<2;
        b=(byte)(a<<2);
        System.out.println("Original value of a: " + a);
        System.out.println(" i and b : " + i + " " + b );
    }

}
