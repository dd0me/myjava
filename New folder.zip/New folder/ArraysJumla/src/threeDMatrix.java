/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class threeDMatrix {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Display a three d matrix
        int threeD [][][] = new int [3][4][5];
        int i,j,k=0;
        for(i=0;i<3;i++)
            for(j=0;j<4;j++)
                for(k=0;k<5;k++)
                    threeD[i][j][k]=i*j*k;

        for(i=0;i<3;i++){
            for(j=0;j<4;j++){
                for(k=0;k<5;k++)

        System.out.print(threeD[i][j][k] + " ");
                System.out.println();
    }
    System.out.println();
    }
}
}
