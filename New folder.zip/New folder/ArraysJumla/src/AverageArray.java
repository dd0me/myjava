/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class AverageArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

       //Average an array of values.
        double nums[]={10.1,11.2,12.3,13.4,14.5};
        double result =0;
        int i;
        for(i=0;i<5;i++)
            result = result + nums[i];
            System.out.println("Average is " + result/5);
    }

}
