/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package conditionz;

/**
 *
 * @author D
 */
public class IfElse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Demonstrate if-else-if statements
        int month=4;//April
        String season;
        if(month==12 || month==1 || month==2)
        season="Winter";
 else if(month==3 || month==4 || month==5)
        season="Spring";
 else if(month==6 || month==7 || month== 7)
        season="Summer";
 else if(month==8 || month==9 || month==10)
        season="Autumn";
 else
     season = "Bogus month";
        System.out.println("April is in the " + season + ".");
    }

}
