/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class BooLogic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Demonstrate the boolean logical operators
        boolean a = true;
        boolean b = false;
        boolean c = a|b;
        boolean d = a & b;
        boolean e = a^b;
        boolean f = (!a & b) | (a & !b);
        boolean g = !a;
        System.out.println(" a = " + a);
        System.out.println(" b = " + b);
        System.out.println(" c = " + c);
        System.out.println(" d = " + d);
        System.out.println(" e = " + e);
        System.out.println(" f = " + f);
        System.out.println(" g = " + g);
            }

}
