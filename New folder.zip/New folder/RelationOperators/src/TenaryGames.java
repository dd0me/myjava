/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class TenaryGames {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       int i,k;
       i=10;
       k=i<0? -i : i;//get absolute value of i
       System.out.print("Absolute value of ");
       System.out.println(i + " is " + k);

       i=-10;
       k=i<0? -i : i;//get absolute value of i
       System.out.print("Absolute value of ");
       System.out.println(i + " is " + k);
       

    }

}
