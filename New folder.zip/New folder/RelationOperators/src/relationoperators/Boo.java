/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package relationoperators;

/**
 *
 * @author D
 */
public class Boo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a = 1;
        int b = 2;
        boolean c = a < b;

       System.out.println(" c = " + c);
    }

}
