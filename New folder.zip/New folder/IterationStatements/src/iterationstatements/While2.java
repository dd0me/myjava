package iterationstatements;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class While2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // While ya java
        int a,b;
        a =10;
        b =20;
        while(a>b){
            System.out.println("This will not be displayed");
        }
    }

}
