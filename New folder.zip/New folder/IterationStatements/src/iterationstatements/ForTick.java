/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package iterationstatements;

/**
 *
 * @author D
 */
public class ForTick {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n;
        for(n=10;n>0;n--)
    System.out.println(" Tick is " + n);

    }


}
