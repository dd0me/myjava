/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package iterationstatements;

/**
 *
 * @author D
 */
public class Sample2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a,b;
        for(a=1,b=4; a<b; a++,b--){
        System.out.println("This is a " + a);
        System.out.println("This is b " + b);

    }

}
}
