package iterationstatements;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class NoBody {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i,j;
        i=100;
        j=200;
        while(++i < --j);
            //There is no body in the while loop statement
            System.out.println(" The Midpoint is " + i );
        
    }

}
