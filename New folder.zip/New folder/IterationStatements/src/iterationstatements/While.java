/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package iterationstatements;

/**
 *
 * @author D
 */
public class While {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Exhibiting the while statement
        int n = 10;
        while (n > 0){
            System.out.println(" tick " + n);
            n--;
            
        }
        
    }

}
