/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package iterationstatements;

/**
 *
 * @author D
 */
public class Nested4Loops {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i,j;
        for(i=0;i<10;i++){
            for(j=0;j<10;j++)
                System.out.print(" . ");
            System.out.println();
        }
    }

}
