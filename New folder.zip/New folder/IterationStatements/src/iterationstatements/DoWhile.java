/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package iterationstatements;

/**
 *
 * @author D
 */
public class DoWhile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Illustrating the do while loop
        int n=1000;
        do
        {
            System.out.println("tick " + n);
            n--;
        } while (n > 0);


    }

}
