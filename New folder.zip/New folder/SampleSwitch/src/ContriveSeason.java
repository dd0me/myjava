/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class ContriveSeason {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // The season example to bring about more uses of this concept
        // An improved version of the season program
        int month = 4;//April
        String Season;
        switch (month) {
            case 12:
            case 1:
            case 2:
                Season="Winter";
                break;
            case 3:
            case 4:
            case 5:
                Season="Spring";
                break;
            case 6:
            case 7:
            case 8:
                Season="Summer";
                break;
            case 9:
            case 10:
            case 11:
                Season="Autumn";
                break;
            default:
                Season="Bogus month";
        }
                System.out.println(" April is in the " + Season + "." );



        }

       
    }


