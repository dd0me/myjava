/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sampleswitch;

/**
 *
 * @author D
 */
public class SampleSwitch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Example of using a switch
        for (int i=0; i<6; i++)
            switch(i) {
                case 0:
                    System.out.println("i is " + i);
                            break;
                case 1:
                    System.out.println( "i is " + i);
                    break;
                case 2:
                    System.out.println("i is " + i);
                    break;
                case 3:
                    System.out.println("i is " + i);
                    break;
                default:
                    System.out.println( "i is greater than 3.");


            }

    }

}
