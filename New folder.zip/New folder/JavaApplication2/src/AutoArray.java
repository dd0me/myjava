/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
public class AutoArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String [] args) {
        // TODO code application logic here

     int month_days[]={31,28,31,30,31,30,31,31,30,31,30,31};
     System.out.println("April has " + month_days[4] + " days");
    }

}
