/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication2;

/**
 *
 * @author D
 */
public class ForTest {
    public static void main (String args []) {
        int x;
        for (x=2;x<1000;x++)
        System.out.println(" This is x:"  + x);
    }


}
