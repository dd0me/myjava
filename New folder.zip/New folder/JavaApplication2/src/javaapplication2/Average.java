package javaapplication2;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author D
 */
//average an array of values
public class Average {
    public static void main(String args[]){
        double nums[]={10.1,11.2,12.3,13.4,14.53};
        double result=0;
        int i;
        for(i=0;i<5;i++)
            result=result+nums[i];
        System.out.println("average is " + result/5);

    }

}
